<?php
//konfigurasi server database
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$debe = 'cbtcandy25';
