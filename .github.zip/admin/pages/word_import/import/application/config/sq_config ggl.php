<?php 
include "../../../../../config/config.default.php";

//include "local_port.php";
//include "user_db.php";
//include "pass_db.php";
//include "nama_db.php";

		$sq_base_url='';
		$sq_hostname='$l_port';
		$sq_dbname='$database';
		$sq_dbusername='$userdb';
		$sq_dbpassword='$passdb';
		
		?>